{{$book->name}}
<br>
{{$book->language->name}}