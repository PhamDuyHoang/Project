<footer id="footer" class="site-footer main-footer footer-bottom-horizontal site-footer-inverted main-footer-inverted">
        <div class="container">
            <div class="footer-widgets">
                <div class="footer--widgets widget-area widgets--columned-layout widgets--columns-4">
                    <div id="text-1" class="widget widget_text">
                        <div class="textwidget">
                            <p class="footer-address">
                                Khoa CNTT
                                <br>
                                ĐH Công nghệ
                                <br>
                                ĐHQG Hà Nội
                                <br>
                                <a href="#">See Location</a>
                            </p>
                        </div>
                    </div>
                    <div id="nav_menu-2" class="widget widget_nav_menu">
                        <div class="menu-footer-menu-1-container">
                            <ul id="menu-footer-menu-1" class="menu">
                                <li class="menu-item menu-item-type-post_type">
                                    <a href="#">Home</a>
                                </li>
                                <li class="menu-item menu-item-type-post_type">
                                    <a href="#">Books</a>
                                </li>
                                <li class="menu-item menu-item-type-post_type">
                                    <a href="#">About</a>
                                </li>
                                <li class="menu-item menu-item-type-post_type">
                                    <a href="#">Blog</a>
                                </li>
                                <li class="menu-item menu-item-type-post_type">
                                    <a href="#">Contact</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div id="nav_menu-3" class="widget widget_nav_menu">
                        <div class="menu-footer-menu-2-container">
                            <ul class="menu">
                                <li class="menu-item menu-item-type-custom">
                                    <a href="#">Bestsellers</a>
                                </li>
                                <li class="menu-item menu-item-type-custom">
                                    <a href="#">On sale</a>
                                </li>
                                <li class="menu-item menu-item-type-custom">
                                    <a href="#">Editor Pick</a>
                                </li>
                                <li class="menu-item menu-item-type-custom">
                                    <a href="#">Best of 2009</a>
                                </li>
                                <li class="menu-item menu-item-type-custom">
                                    <a href="#">Featured</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div id="text-2" class="widget widget_text">
                        <div class="textwidget">
                            <p>Tel:
                                <a href="tel: +123456789">123-456-789</a>
                            </p>
                            <p>E-mail:
                                <a href="mailto:info@example.com">info@example.com</a>
                            </p>
                            <p></p>
                            <table border="0" cellspacing="0" cellpadding="10" align="center">
                                <tbody>
                                    <tr>
                                        <td align="center"></td>
                                    </tr>
                                    <tr>
                                        <td align="center">
                                            <a href="#">
                                                <img class="payment-methods-footer" src="https://www.paypalobjects.com/webstatic/mktg/logo/AM_SbyPP_mc_vs_dc_ae.jpg" alt="PayPal Acceptance Mark" border="0">
                                            </a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <div class="footer-bottom-content">
                    <div class="footer-content-right">&copy; Copyright 2019 &nbsp;&nbsp;.&nbsp;&nbsp;All Rights Reserved</div>
                    <!-- <div class="footer-content-left">
                        <div class="copyrights site-info">
                            <ul class="social-networks rounded">
                                <li>
                                    <a href="#"class="facebook" rel="noopener">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#"class="twitter" rel="noopener">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li><a href="#" class="instagram"><i class="fa fa-instagram"></span></a></li>
                                <li><a href="" class="custom"><i class="fa fa-medium"></i></a></li>
                            </ul>
                        </div>
                    </div> -->
                </div>
            </div>
        </div>
    </footer>